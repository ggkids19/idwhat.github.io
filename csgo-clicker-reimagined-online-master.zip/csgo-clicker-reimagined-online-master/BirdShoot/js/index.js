/**Second Version***
KILL THE BIRDS PURE CSS GAME - NO JS
------------------------------
Author: Elad Shechter
http://il.linkedin.com/in/eladshechter/
https://medium.com/@elad
https://coderwall.com/p/u/elad2412

MY FACEBOOK GROUP
https://www.facebook.com/groups/css.master/


The Bird taken from:
-------------------------------
http://codepen.io/fixcl/pen/KhAqa

Author: Marco Barría 
https://twitter.com/marco_bf

******/