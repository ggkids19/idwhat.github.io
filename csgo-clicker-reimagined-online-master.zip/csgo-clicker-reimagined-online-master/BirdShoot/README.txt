A Pen created at CodePen.io. You can find this one at http://codepen.io/elad2412/pen/hBaqo.

 KIll The Birds