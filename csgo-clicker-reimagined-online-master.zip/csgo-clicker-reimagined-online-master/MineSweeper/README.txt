A Pen created at CodePen.io. You can find this one at http://codepen.io/coderontheroad/pen/Fbfjh.

 It's a minesweeper game with js.