A Pen created at CodePen.io. You can find this one at http://codepen.io/joshbader/pen/yYpGwo.

 A short game based on the Movie Back to the Future in honour of Back to the Future Day (October 21st, 2015).