A Pen created at CodePen.io. You can find this one at http://codepen.io/lloydfenton/pen/JXvegz.

 A card flipping pairs game using css animation with jQuery.

CSS preprocessor is Bourbon.