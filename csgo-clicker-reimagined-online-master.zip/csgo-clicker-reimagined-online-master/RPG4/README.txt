A Pen created at CodePen.io. You can find this one at http://codepen.io/jbmartinez/pen/dGqKer.

 A roguelike game made with React.js. Move with the arrow keys, increase your XP by killing enemies, exit through the door and repeat until you beat the boss 