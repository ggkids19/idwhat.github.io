A Pen created at CodePen.io. You can find this one at http://codepen.io/towc/pen/jqBWOZ.

 Manually-generate coordinates for a 3d render of an old desktop computer on the 2d canvas context (no libraries), including a playable game of pong! :D (Yes, the ball gets faster every time you hit it)