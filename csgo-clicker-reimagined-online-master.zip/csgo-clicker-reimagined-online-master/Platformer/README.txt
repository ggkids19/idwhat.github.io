A Pen created at CodePen.io. You can find this one at http://codepen.io/Gthibaud/pen/EVoopL.

 not really a game, but have coin collector and title menu and sprite animation