A Pen created at CodePen.io. You can find this one at http://codepen.io/RSH87/pen/xGrPXq.

 A little game i made playing with perspective. Hover to start and avoid the cops! and post your highscore! 