A Pen created at CodePen.io. You can find this one at http://codepen.io/dissimulate/pen/CqIxk.

 A simple platform game engine, the map is customisable and scriptable. Refer to the comments in the "map" variable for instructions.

I plan to expand the engine in the future, the ability to use images for tiles and the player is one thing that I have in mind. Any suggestions are welcome.